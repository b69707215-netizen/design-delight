-- Roles enum
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('student', 'teacher');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- user_roles table
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE POLICY "view own role" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "create own role" ON public.user_roles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND role IN ('student','teacher'));
CREATE POLICY "delete own role" ON public.user_roles
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON public.user_roles(user_id);

-- payment_history table
CREATE TABLE IF NOT EXISTS public.payment_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  program_title TEXT NOT NULL,
  lessons_purchased INTEGER NOT NULL DEFAULT 0,
  amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'UAH',
  status TEXT NOT NULL DEFAULT 'pending',
  provider TEXT NOT NULL DEFAULT 'manual',
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.payment_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view own payment history" ON public.payment_history
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_payment_history_user_id ON public.payment_history(user_id);
CREATE INDEX IF NOT EXISTS idx_payment_history_paid_at ON public.payment_history(paid_at DESC);
CREATE TRIGGER payment_history_set_updated_at BEFORE UPDATE ON public.payment_history
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- curator_chat_messages table
CREATE TABLE IF NOT EXISTS public.curator_chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL,
  teacher_id UUID NOT NULL,
  sender_id UUID NOT NULL,
  message TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.curator_chat_messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_curator_chat_student_created ON public.curator_chat_messages(student_id, created_at);
CREATE INDEX IF NOT EXISTS idx_curator_chat_teacher_created ON public.curator_chat_messages(teacher_id, created_at);
CREATE TRIGGER curator_chat_messages_set_updated_at BEFORE UPDATE ON public.curator_chat_messages
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE POLICY "students view own chats" ON public.curator_chat_messages
  FOR SELECT TO authenticated USING (auth.uid() = student_id);
CREATE POLICY "teachers view assigned chats" ON public.curator_chat_messages
  FOR SELECT TO authenticated USING (auth.uid() = teacher_id);
CREATE POLICY "students send messages" ON public.curator_chat_messages
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = student_id AND sender_id = auth.uid() AND public.has_role(auth.uid(), 'student'));
CREATE POLICY "teachers reply messages" ON public.curator_chat_messages
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = teacher_id AND sender_id = auth.uid() AND public.has_role(auth.uid(), 'teacher'));
CREATE POLICY "participants mark read" ON public.curator_chat_messages
  FOR UPDATE TO authenticated
  USING (auth.uid() = student_id OR auth.uid() = teacher_id)
  WITH CHECK (auth.uid() = student_id OR auth.uid() = teacher_id);