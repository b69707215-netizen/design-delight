---
name: Brand color palette
description: Official brand colors — black, gold, cream (milky), caramel. Used across all UI.
type: design
---
Палитра проекта (4 цвета):
- Чёрный (background, тёмные поверхности)
- Золотой (primary / акценты, gradient-gold, кнопки royal)
- Молочный / cream (foreground, текст на тёмном)
- Карамельный (вторичный тёплый акцент)

Никаких фиолетовых, синих, зелёных и пр. Все новые токены — только в этой палитре.
Определяются в src/styles.css как oklch.