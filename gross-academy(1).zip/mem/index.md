# Project Memory

## Core
Brand palette strict: black, gold, cream (milky), caramel only. No purple/blue/green.
Use semantic tokens from src/styles.css (oklch). Never hardcode colors in components.

## Memories
- [Color palette](mem://design/palette) — official 4-color brand palette