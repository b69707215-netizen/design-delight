import { useCallback, useEffect, useSyncExternalStore } from "react";

export type Theme = "dark" | "light";

const storageKey = "gross-academy-theme";
const themeChangedEvent = "gross-academy-theme-changed";

function normalize(value: string | null): Theme {
  return value === "light" ? "light" : "dark";
}

function getSnapshot(): Theme {
  if (typeof window === "undefined") return "dark";
  return normalize(window.localStorage.getItem(storageKey));
}

function subscribe(callback: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener("storage", callback);
  window.addEventListener(themeChangedEvent, callback);
  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener(themeChangedEvent, callback);
  };
}

function applyTheme(theme: Theme) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.toggle("light", theme === "light");
  root.classList.toggle("dark", theme === "dark");
  root.dataset.theme = theme;
}

export function useTheme() {
  const theme = useSyncExternalStore<Theme>(subscribe, getSnapshot, () => "dark");

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  const setTheme = useCallback((next: Theme) => {
    window.localStorage.setItem(storageKey, next);
    applyTheme(next);
    window.dispatchEvent(new Event(themeChangedEvent));
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(getSnapshot() === "dark" ? "light" : "dark");
  }, [setTheme]);

  return { theme, setTheme, toggleTheme };
}