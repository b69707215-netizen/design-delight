import { createFileRoute } from "@tanstack/react-router";
import { Layout, SectionTitle, ContactForm } from "@/components/Layout";
import { useLanguage } from "@/lib/use-language";
import { translations } from "@/lib/academy-content";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Контакти — Gross Academy" },
      { name: "description", content: "Залиш контакти та запишись на пробний урок." },
      { property: "og:title", content: "Контакти — Gross Academy" },
      { property: "og:description", content: "Запис на пробний урок." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <Layout>
      <section className="mx-auto max-w-4xl px-5 py-20 md:px-10">
        <SectionTitle kicker={t.contactKicker} title={t.contactTitle} />
        <ContactForm title={t.trialLesson} />
      </section>
    </Layout>
  );
}
