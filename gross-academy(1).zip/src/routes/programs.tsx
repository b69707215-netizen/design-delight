import { createFileRoute } from "@tanstack/react-router";
import { Layout, SectionTitle, ContactForm } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/lib/use-language";
import { translations, programs, type Language } from "@/lib/academy-content";

function localized<T extends Record<Language, string>>(value: T, language: Language) {
  return value[language];
}

export const Route = createFileRoute("/programs")({
  head: () => ({
    meta: [
      { title: "Програми — Gross Academy" },
      { name: "description", content: "Шахові програми від базового старту до шляху гросмейстера." },
      { property: "og:title", content: "Програми навчання — Gross Academy" },
      { property: "og:description", content: "Сім тарифів, від групових уроків до елітної підготовки." },
    ],
  }),
  component: ProgramsPage,
});

function ProgramsPage() {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-5 py-20 md:px-10">
        <SectionTitle kicker={t.programsKicker} title={t.programsTitle} />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {programs.map((program) => (
            <article
              key={program.slug}
              className="rounded-xl border border-royal-border bg-[image:var(--gradient-surface)] p-8 shadow-royal transition-all hover:-translate-y-2 hover:border-gold hover:shadow-gold"
            >
              <div className="text-sm font-semibold tracking-[0.35em] text-gold">{program.mark}</div>
              <h2 className="mt-8 text-2xl font-semibold text-gold">{localized(program.title, language)}</h2>
              <p className="mt-2 text-sm text-warm-muted">{localized(program.lessons, language)}</p>
              <p className="mt-5 text-3xl font-semibold text-cream">{localized(program.price, language)}</p>
              <p className="mt-5 text-sm leading-7 text-warm-muted">{localized(program.text, language)}</p>
              <Button asChild variant="royal" className="mt-7 w-full">
                <a href={program.paymentUrl} target="_blank" rel="noreferrer">
                  {language === "en" ? "Pay" : "Оплатити"}
                </a>
              </Button>
            </article>
          ))}
        </div>
        <ContactForm compact title={t.chooseProgram} />
      </section>
    </Layout>
  );
}
