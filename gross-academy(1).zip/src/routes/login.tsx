import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Layout, FormField } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/use-language";

type Role = "student" | "teacher";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Вхід — Gross Academy" },
      { name: "description", content: "Особистий кабінет учня та вчителя Gross Academy." },
    ],
  }),
  component: Login,
});

function Login() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const { language, setLanguage } = useLanguage();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [role, setRole] = useState<Role>("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);

  const copy =
    language === "en"
      ? {
          title: "Personal account",
          subtitle: "Sign in or create a student/teacher account.",
          signin: "Sign in",
          signup: "Create account",
          password: "Password",
          fullName: "Full name",
          student: "Student",
          teacher: "Teacher",
          google: "Continue with Google",
          successSignup: "Check your email to confirm registration.",
          roleLabel: "Role",
        }
      : {
          title: "Особистий кабінет",
          subtitle: "Увійдіть або створіть кабінет учня/вчителя.",
          signin: "Увійти",
          signup: "Створити акаунт",
          password: "Пароль",
          fullName: "Повне ім’я",
          student: "Учень",
          teacher: "Вчитель",
          google: "Продовжити з Google",
          successSignup: "Перевірте пошту, щоб підтвердити реєстрацію.",
          roleLabel: "Роль",
        };

  useEffect(() => {
    if (!loading && user) navigate({ to: "/dashboard", replace: true });
  }, [user, loading, navigate]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { full_name: fullName, role },
          },
        });
        if (error) throw error;
        if (data.session && data.user) {
          await supabase.from("user_roles").insert({ user_id: data.user.id, role });
          navigate({ to: "/dashboard", replace: true });
        } else {
          toast.success(copy.successSignup);
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard", replace: true });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Error");
    } finally {
      setBusy(false);
    }
  }

  async function googleSignIn() {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/dashboard`,
    });
    if (result.error) {
      toast.error(language === "en" ? "Google sign-in failed" : "Не вдалося увійти через Google");
      setBusy(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard", replace: true });
  }

  return (
    <Layout>
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-[0.9fr_1.1fr] md:px-10">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.32em] text-gold">GROSS ACADEMY</p>
          <h1 className="mt-5 font-display text-4xl font-semibold text-cream md:text-6xl">{copy.title}</h1>
          <p className="mt-6 text-lg leading-8 text-warm-muted">{copy.subtitle}</p>
          <button
            type="button"
            onClick={() => setLanguage(language === "uk" ? "en" : "uk")}
            className="mt-8 rounded-md border border-royal-border bg-royal-surface px-4 py-2 text-sm font-semibold text-cream shadow-royal hover:border-gold"
          >
            {language === "uk" ? "English" : "Українська"}
          </button>
        </div>
        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-royal-border bg-royal-surface-strong p-6 shadow-royal md:p-10"
        >
          <div className="mb-7 grid grid-cols-2 gap-3">
            <Button type="button" variant={mode === "signin" ? "royal" : "royalOutline"} onClick={() => setMode("signin")}>
              {copy.signin}
            </Button>
            <Button type="button" variant={mode === "signup" ? "royal" : "royalOutline"} onClick={() => setMode("signup")}>
              {copy.signup}
            </Button>
          </div>
          {mode === "signup" && (
            <FormField label={copy.fullName} placeholder={copy.fullName} value={fullName} onChange={setFullName} />
          )}
          <FormField label="Email" placeholder="your@email.com" type="email" value={email} onChange={setEmail} />
          <FormField label={copy.password} placeholder="••••••••" type="password" value={password} onChange={setPassword} />
          {mode === "signup" && (
            <label className="mt-5 block text-sm font-semibold text-gold">
              {copy.roleLabel}
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as Role)}
                className="mt-2 h-12 w-full rounded-md border border-royal-border bg-input px-4 text-cream focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="student">{copy.student}</option>
                <option value="teacher">{copy.teacher}</option>
              </select>
            </label>
          )}
          <Button disabled={busy} type="submit" variant="royal" size="lg" className="mt-8 w-full">
            {mode === "signin" ? copy.signin : copy.signup}
          </Button>
          <Button type="button" variant="royalOutline" size="lg" className="mt-3 w-full" onClick={googleSignIn} disabled={busy}>
            {copy.google}
          </Button>
        </form>
      </section>
    </Layout>
  );
}
