import { createFileRoute } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { useLanguage } from "@/lib/use-language";
import { translations } from "@/lib/academy-content";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Про нас — Gross Academy" },
      { name: "description", content: "Філософія Gross Academy: стратегія, дисципліна, впевнені рішення." },
      { property: "og:title", content: "Про академію — Gross Academy" },
      { property: "og:description", content: "Ми не вчимо просто пересувати фігури." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <Layout>
      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-20 md:grid-cols-[1.05fr_0.95fr] md:px-10">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.32em] text-gold">{t.aboutKicker}</p>
          <h1 className="mt-5 text-4xl font-semibold leading-tight text-cream md:text-6xl">{t.aboutTitle}</h1>
          <p className="mt-7 text-lg leading-9 text-warm-muted">{t.aboutText}</p>
          <div className="mt-10 grid gap-5">
            {t.advantages.map(([title, text]) => (
              <article key={title} className="border-l-4 border-gold bg-gold/5 p-5">
                <h2 className="font-semibold text-gold">{title}</h2>
                <p className="mt-2 text-sm leading-7 text-warm-muted">{text}</p>
              </article>
            ))}
          </div>
        </div>
        <div className="grid min-h-[420px] place-items-center rounded-xl border border-royal-border bg-gold/10 text-[10rem] text-gold/35 shadow-royal">
          ♔
        </div>
      </section>
    </Layout>
  );
}
