import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Layout, SectionTitle } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/use-language";

type Payment = {
  id: string;
  amount: number;
  currency: string;
  status: string;
  description: string | null;
  created_at: string;
};

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Кабінет — Gross Academy" },
      { name: "description", content: "Особистий кабінет учня та вчителя." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const navigate = useNavigate();
  const { user, profile, loading, refreshProfile, signOut } = useAuth();
  const { language } = useLanguage();
  const [fullName, setFullName] = useState("");
  const [payments, setPayments] = useState<Payment[]>([]);
  const [saving, setSaving] = useState(false);

  const copy =
    language === "en"
      ? {
          kicker: "Personal cabinet",
          hello: "Hello",
          backHome: "To the site",
          openPayments: "Payment history",
          openChat: "Curator chat",
          logout: "Log out",
          profile: "Profile",
          email: "Email",
          name: "Full name",
          save: "Save",
          payments: "Recent payments",
          empty: "No payments yet.",
          loading: "Loading…",
          saved: "Saved",
        }
      : {
          kicker: "Особистий кабінет",
          hello: "Вітаємо",
          backHome: "На сайт",
          openPayments: "Історія оплат",
          openChat: "Чат з куратором",
          logout: "Вийти",
          profile: "Профіль",
          email: "Email",
          name: "Ім’я та прізвище",
          save: "Зберегти",
          payments: "Останні оплати",
          empty: "Оплат поки немає.",
          loading: "Завантаження…",
          saved: "Збережено",
        };

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/login", replace: true });
  }, [user, loading, navigate]);

  useEffect(() => {
    if (profile) setFullName(profile.full_name ?? "");
  }, [profile]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("payments")
      .select("id,amount,currency,status,description,created_at")
      .order("created_at", { ascending: false })
      .then(({ data }) => setPayments((data ?? []) as Payment[]));
  }, [user]);

  async function saveProfile() {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ full_name: fullName }).eq("id", user.id);
    setSaving(false);
    if (error) toast.error(error.message);
    else {
      toast.success(copy.saved);
      await refreshProfile();
    }
  }

  async function logout() {
    await signOut();
    navigate({ to: "/", replace: true });
  }

  if (loading || !user) {
    return (
      <Layout>
        <div className="grid min-h-[60vh] place-items-center text-warm-muted">{copy.loading}</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="mx-auto max-w-5xl px-5 py-20 md:px-10">
        <SectionTitle kicker={copy.kicker} title={`${copy.hello}, ${profile?.full_name || user.email}`} />

        <div className="mb-6 flex flex-wrap items-center justify-end gap-2">
          <Button asChild variant="royalOutline" size="sm">
            <Link to="/payment-history">{copy.openPayments}</Link>
          </Button>
          <Button asChild variant="royalOutline" size="sm">
            <Link to="/curator-chat">{copy.openChat}</Link>
          </Button>
          <Button asChild variant="royalOutline" size="sm">
            <Link to="/">{copy.backHome}</Link>
          </Button>
          <Button onClick={logout} variant="royalOutline" size="sm">
            {copy.logout}
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-royal-border bg-royal-surface p-6 shadow-royal md:p-8">
            <h2 className="text-2xl font-semibold text-gold">{copy.profile}</h2>
            <div className="mt-6 grid gap-4">
              {profile?.avatar_url && (
                <img src={profile.avatar_url} alt="" className="size-20 rounded-full border border-gold/40" />
              )}
              <div className="grid gap-2">
                <Label className="text-gold">{copy.email}</Label>
                <Input value={user.email ?? ""} disabled className="bg-input text-cream" />
              </div>
              <div className="grid gap-2">
                <Label className="text-gold">{copy.name}</Label>
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} className="bg-input text-cream" />
              </div>
              <Button onClick={saveProfile} disabled={saving} variant="royal">
                {copy.save}
              </Button>
            </div>
          </div>

          <div className="rounded-xl border border-royal-border bg-royal-surface p-6 shadow-royal md:p-8">
            <h2 className="text-2xl font-semibold text-gold">{copy.payments}</h2>
            <div className="mt-6 grid gap-3">
              {payments.length === 0 ? (
                <p className="text-warm-muted">{copy.empty}</p>
              ) : (
                payments.map((p) => (
                  <article key={p.id} className="flex items-center justify-between rounded-md border border-royal-border bg-royal-surface-strong p-4">
                    <div>
                      <p className="font-semibold text-cream">{p.description ?? "Payment"}</p>
                      <p className="text-xs text-warm-muted">
                        {new Date(p.created_at).toLocaleString(language === "en" ? "en-US" : "uk-UA")}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gold">
                        {(p.amount / 100).toFixed(2)} {p.currency.toUpperCase()}
                      </p>
                      <p className="text-xs text-warm-muted">{p.status}</p>
                    </div>
                  </article>
                ))
              )}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
