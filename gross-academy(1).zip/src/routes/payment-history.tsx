import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Layout, SectionTitle } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/use-language";

type Payment = {
  id: string;
  program_title: string;
  lessons_purchased: number;
  amount: number;
  currency: string;
  status: string;
  provider: string;
  paid_at: string | null;
  created_at: string;
};
type StatusFilter = "all" | "paid" | "canceled" | "pending";
const STATUSES: StatusFilter[] = ["all", "paid", "canceled", "pending"];
function normalize(status: string): Exclude<StatusFilter, "all"> {
  const v = status.toLowerCase();
  if (["paid", "success", "succeeded", "complete", "completed"].includes(v)) return "paid";
  if (["canceled", "cancelled", "failed", "refunded"].includes(v)) return "canceled";
  return "pending";
}

export const Route = createFileRoute("/payment-history")({
  head: () => ({
    meta: [
      { title: "Історія оплат — Gross Academy" },
      { name: "description", content: "Усі оплати за програмами в особистому кабінеті." },
    ],
  }),
  component: PaymentHistoryPage,
});

function PaymentHistoryPage() {
  const { user, loading: authLoading } = useAuth();
  const { language } = useLanguage();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [course, setCourse] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");

  const copy =
    language === "en"
      ? { kicker: "Cabinet", title: "Payment history", course: "Course", status: "Status",
          allCourses: "All courses", allStatuses: "All statuses",
          paid: "Paid", canceled: "Canceled", pending: "Pending",
          amount: "Amount", lessons: "Lessons", empty: "No payments match these filters.",
          signin: "Sign in to view your payment history.", back: "Back to cabinet", login: "Sign in", loading: "Loading…" }
      : { kicker: "Кабінет", title: "Історія оплат", course: "Курс", status: "Статус",
          allCourses: "Усі курси", allStatuses: "Усі статуси",
          paid: "Успішно", canceled: "Скасовано", pending: "В очікуванні",
          amount: "Сума", lessons: "Уроків", empty: "За цими фільтрами оплат немає.",
          signin: "Увійдіть, щоб переглянути історію оплат.", back: "Назад до кабінету", login: "Увійти", loading: "Завантаження…" };

  useEffect(() => {
    let alive = true;
    if (!user) {
      setLoading(false);
      return;
    }
    (async () => {
      const { data } = await supabase
        .from("payment_history")
        .select("id, program_title, lessons_purchased, amount, currency, status, provider, paid_at, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (!alive) return;
      setPayments((data ?? []) as Payment[]);
      setLoading(false);
    })();
    return () => { alive = false; };
  }, [user]);

  const courseOptions = useMemo(
    () => Array.from(new Set(payments.map((p) => p.program_title))).sort(),
    [payments],
  );
  const filtered = payments.filter(
    (p) => (!course || p.program_title === course) && (status === "all" || normalize(p.status) === status),
  );

  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-5 py-20 md:px-10">
        <SectionTitle kicker={copy.kicker} title={copy.title} />
        {!user && !authLoading ? (
          <div className="mx-auto max-w-xl rounded-xl border border-royal-border bg-royal-surface p-8 text-center shadow-royal">
            <p className="text-warm-muted">{copy.signin}</p>
            <Button asChild variant="royal" className="mt-6">
              <Link to="/login">{copy.login}</Link>
            </Button>
          </div>
        ) : (
          <div className="rounded-xl border border-royal-border bg-royal-surface p-6 shadow-royal md:p-8">
            <div className="grid gap-4 md:grid-cols-[1fr_1fr_auto]">
              <label className="block text-sm font-semibold text-gold">
                {copy.course}
                <select
                  value={course}
                  onChange={(e) => setCourse(e.target.value)}
                  className="mt-2 h-12 w-full rounded-md border border-royal-border bg-input px-4 text-cream focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="">{copy.allCourses}</option>
                  {courseOptions.map((title) => (
                    <option key={title} value={title}>{title}</option>
                  ))}
                </select>
              </label>
              <label className="block text-sm font-semibold text-gold">
                {copy.status}
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as StatusFilter)}
                  className="mt-2 h-12 w-full rounded-md border border-royal-border bg-input px-4 text-cream focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {STATUSES.map((v) => (
                    <option key={v} value={v}>{v === "all" ? copy.allStatuses : copy[v]}</option>
                  ))}
                </select>
              </label>
              <Button asChild variant="royalOutline" className="self-end">
                <Link to="/dashboard">{copy.back}</Link>
              </Button>
            </div>
            <div className="mt-8 grid gap-4">
              {loading ? (
                <p className="text-sm text-warm-muted">{copy.loading}</p>
              ) : filtered.length === 0 ? (
                <p className="text-sm text-warm-muted">{copy.empty}</p>
              ) : (
                filtered.map((p) => {
                  const n = normalize(p.status);
                  return (
                    <article key={p.id} className="rounded-md border border-royal-border bg-royal-surface-strong p-5">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <h2 className="font-semibold text-cream">{p.program_title}</h2>
                        <span className="text-sm font-semibold text-gold">{copy[n]}</span>
                      </div>
                      <p className="mt-3 text-sm text-warm-muted">
                        {copy.amount}: {p.amount} {p.currency} · {copy.lessons}: {p.lessons_purchased} · {p.provider}
                      </p>
                    </article>
                  );
                })
              )}
            </div>
          </div>
        )}
      </section>
    </Layout>
  );
}
