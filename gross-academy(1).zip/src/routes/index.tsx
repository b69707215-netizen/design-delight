import { createFileRoute, Link } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/lib/use-language";
import { translations } from "@/lib/academy-content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Gross Academy — шахи від майстрів" },
      { name: "description", content: "Шахова академія для дітей, дорослих і профі. Персональні програми та турнірна підготовка." },
      { property: "og:title", content: "Gross Academy" },
      { property: "og:description", content: "Твій шлях до гросмейстерського рівня." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <Layout>
      <section className="relative flex min-h-[720px] items-center justify-center px-5 py-20 text-center md:px-10">
        <div className="absolute -right-32 -top-40 size-[560px] rounded-full bg-gold/15 blur-3xl animate-royal-pulse" />
        <div className="absolute bottom-12 left-8 hidden h-56 w-40 rotate-12 border border-royal-border bg-royal-surface/40 shadow-royal animate-float md:block" />
        <div className="relative z-10 mx-auto max-w-5xl">
          <p className="mb-5 text-sm font-semibold uppercase tracking-[0.36em] text-gold">{t.heroKicker}</p>
          <h1 className="text-balance font-display text-5xl font-semibold leading-tight tracking-[0.03em] text-cream md:text-7xl">
            ♔ GROSS ACADEMY
          </h1>
          <p className="mx-auto mt-7 max-w-2xl text-lg leading-8 text-warm-muted md:text-xl">{t.heroText}</p>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button asChild variant="royal" size="lg">
              <Link to="/contact">{t.ctaTrial}</Link>
            </Button>
            <Button asChild variant="royalOutline" size="lg">
              <Link to="/programs">{t.ctaPrograms}</Link>
            </Button>
          </div>
          <div className="mx-auto mt-16 grid max-w-5xl gap-5 md:grid-cols-3">
            {t.audiences.map(([symbol, title, text]) => (
              <article
                key={title}
                className="group rounded-xl border border-royal-border bg-royal-surface p-7 text-left shadow-royal transition-all hover:-translate-y-2 hover:border-gold hover:bg-royal-surface-strong"
              >
                <div className="mb-5 text-5xl text-gold transition-transform group-hover:scale-110">{symbol}</div>
                <h2 className="text-xl font-semibold text-gold">{title}</h2>
                <p className="mt-3 text-sm leading-7 text-warm-muted">{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
