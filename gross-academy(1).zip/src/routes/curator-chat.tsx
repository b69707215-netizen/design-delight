import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Layout, SectionTitle } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/use-language";

type Role = "student" | "teacher";
type ChatMessage = {
  id: string;
  student_id: string;
  teacher_id: string;
  sender_id: string;
  message: string;
  created_at: string;
};

export const Route = createFileRoute("/curator-chat")({
  head: () => ({
    meta: [
      { title: "Чат з куратором — Gross Academy" },
      { name: "description", content: "Спілкування учнів і вчителів у персональному кабінеті." },
    ],
  }),
  component: CuratorChatPage,
});

function CuratorChatPage() {
  const { user, loading: authLoading } = useAuth();
  const { language } = useLanguage();
  const [role, setRole] = useState<Role>("student");
  const [hasRole, setHasRole] = useState(false);
  const [peerId, setPeerId] = useState("");
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [savingRole, setSavingRole] = useState(false);

  const copy =
    language === "en"
      ? { kicker: "Cabinet", title: "Curator chat", chooseRole: "Choose your role to start chatting:",
          iAmStudent: "I am a student", iAmTeacher: "I am a teacher",
          yourRole: "Your role", student: "student", teacher: "teacher", yourId: "Your ID",
          teacherId: "Teacher ID", studentId: "Student ID",
          placeholder: "Paste the user ID",
          send: "Send", message: "Message",
          empty: "Messages will appear here after the first reply.",
          signin: "Sign in to open the curator chat.",
          back: "Back to cabinet", login: "Sign in" }
      : { kicker: "Кабінет", title: "Чат з куратором", chooseRole: "Оберіть свою роль для спілкування:",
          iAmStudent: "Я учень", iAmTeacher: "Я вчитель",
          yourRole: "Ваша роль", student: "учень", teacher: "вчитель", yourId: "Ваш ID",
          teacherId: "ID вчителя", studentId: "ID учня",
          placeholder: "Вставте user ID профілю",
          send: "Надіслати", message: "Повідомлення",
          empty: "Повідомлення з’являться тут після першої відповіді.",
          signin: "Увійдіть, щоб відкрити чат з куратором.",
          back: "Назад до кабінету", login: "Увійти" };

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id).limit(1);
      const r = (data?.[0]?.role as Role | undefined) ?? null;
      if (r) { setRole(r); setHasRole(true); }
    })();
  }, [user]);

  async function loadMessages(uid: string, r: Role, peer: string) {
    if (!peer.trim()) { setMessages([]); return; }
    const studentId = r === "student" ? uid : peer.trim();
    const teacherId = r === "teacher" ? uid : peer.trim();
    const { data } = await supabase
      .from("curator_chat_messages")
      .select("id, student_id, teacher_id, sender_id, message, created_at")
      .eq("student_id", studentId).eq("teacher_id", teacherId)
      .order("created_at", { ascending: true });
    setMessages((data ?? []) as ChatMessage[]);
  }

  useEffect(() => {
    if (!user || !hasRole) return;
    loadMessages(user.id, role, peerId);
  }, [user, hasRole, role, peerId]);

  async function chooseRole(r: Role) {
    if (!user) return;
    setSavingRole(true);
    const { error } = await supabase.from("user_roles").insert({ user_id: user.id, role: r });
    setSavingRole(false);
    if (!error) { setRole(r); setHasRole(true); }
    else alert(error.message);
  }

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user || !peerId.trim() || !message.trim()) return;
    const studentId = role === "student" ? user.id : peerId.trim();
    const teacherId = role === "teacher" ? user.id : peerId.trim();
    const { error } = await supabase.from("curator_chat_messages").insert({
      student_id: studentId, teacher_id: teacherId, sender_id: user.id, message: message.trim(),
    });
    if (error) { alert(error.message); return; }
    setMessage("");
    await loadMessages(user.id, role, peerId);
  }

  return (
    <Layout>
      <section className="mx-auto max-w-5xl px-5 py-20 md:px-10">
        <SectionTitle kicker={copy.kicker} title={copy.title} />
        {!user && !authLoading ? (
          <div className="mx-auto max-w-xl rounded-xl border border-royal-border bg-royal-surface p-8 text-center shadow-royal">
            <p className="text-warm-muted">{copy.signin}</p>
            <Button asChild variant="royal" className="mt-6"><Link to="/login">{copy.login}</Link></Button>
          </div>
        ) : !hasRole && user ? (
          <div className="mx-auto max-w-xl rounded-xl border border-royal-border bg-royal-surface p-8 text-center shadow-royal">
            <p className="text-warm-muted">{copy.chooseRole}</p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Button disabled={savingRole} onClick={() => chooseRole("student")} variant="royal">{copy.iAmStudent}</Button>
              <Button disabled={savingRole} onClick={() => chooseRole("teacher")} variant="royalOutline">{copy.iAmTeacher}</Button>
            </div>
          </div>
        ) : (
          <div className="rounded-xl border border-royal-border bg-royal-surface p-6 shadow-royal md:p-8">
            <p className="mb-4 text-sm text-warm-muted">
              {copy.yourRole}: <span className="font-semibold text-gold">{role === "student" ? copy.student : copy.teacher}</span>
              {" · "}{copy.yourId}: <code className="text-cream">{user?.id}</code>
            </p>
            <label className="block text-sm font-semibold text-gold">
              {role === "student" ? copy.teacherId : copy.studentId}
              <input
                value={peerId} onChange={(e) => setPeerId(e.target.value)} placeholder={copy.placeholder}
                className="mt-2 h-12 w-full rounded-md border border-royal-border bg-input px-4 text-cream placeholder:text-warm-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </label>
            <div className="mt-6 grid min-h-80 gap-4 rounded-md border border-royal-border bg-royal-surface-strong p-4">
              {messages.length === 0 ? (
                <p className="self-center text-center text-sm text-warm-muted">{copy.empty}</p>
              ) : (
                messages.map((m) => (
                  <article key={m.id}
                    className={`max-w-[82%] rounded-md border border-royal-border p-4 ${m.sender_id === user?.id ? "ml-auto bg-gold/10" : "bg-royal-surface"}`}>
                    <p className="text-sm leading-6 text-cream">{m.message}</p>
                    <time className="mt-2 block text-xs text-warm-muted">
                      {new Date(m.created_at).toLocaleString(language === "en" ? "en-US" : "uk-UA")}
                    </time>
                  </article>
                ))
              )}
            </div>
            <form onSubmit={sendMessage} className="mt-5 grid gap-4">
              <label className="block text-sm font-semibold text-gold">
                {copy.message}
                <textarea required value={message} onChange={(e) => setMessage(e.target.value)}
                  className="mt-2 min-h-28 w-full rounded-md border border-royal-border bg-input px-4 py-3 text-cream placeholder:text-warm-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
              </label>
              <div className="flex flex-col gap-3 sm:flex-row">
                <Button type="submit" variant="royal" className="flex-1">{copy.send}</Button>
                <Button asChild variant="royalOutline" className="flex-1"><Link to="/dashboard">{copy.back}</Link></Button>
              </div>
            </form>
          </div>
        )}
      </section>
    </Layout>
  );
}
