import { Link } from "@tanstack/react-router";
import { ReactNode, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/use-language";
import { useTheme } from "@/lib/use-theme";
import { translations, programs, type Language } from "@/lib/academy-content";

function localized<T extends Record<Language, string>>(value: T, language: Language) {
  return value[language];
}

export function Header() {
  const { user } = useAuth();
  const { language, setLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const t = translations[language];
  return (
    <header className="sticky top-0 z-50 border-b border-royal-border bg-background/85 px-5 py-4 backdrop-blur-xl md:px-10">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
        <Link
          to="/"
          className="font-display text-lg font-semibold tracking-[0.16em] text-gold md:text-2xl"
        >
          ♔ GROSS ACADEMY
        </Link>
        <nav className="hidden items-center gap-6 text-xs font-semibold uppercase tracking-[0.18em] text-cream md:flex">
          <Link to="/" activeOptions={{ exact: true }} activeProps={{ className: "text-gold" }} className="transition-colors hover:text-gold">
            {t.nav.home}
          </Link>
          <Link to="/programs" activeProps={{ className: "text-gold" }} className="transition-colors hover:text-gold">
            {t.nav.programs}
          </Link>
          <Link to="/about" activeProps={{ className: "text-gold" }} className="transition-colors hover:text-gold">
            {t.nav.about}
          </Link>
          <Link to="/contact" activeProps={{ className: "text-gold" }} className="transition-colors hover:text-gold">
            {t.nav.contact}
          </Link>
          {user && (
            <Link to="/dashboard" activeProps={{ className: "text-gold" }} className="transition-colors hover:text-gold">
              {t.nav.cabinet}
            </Link>
          )}
        </nav>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            title={theme === "dark" ? "Light theme" : "Dark theme"}
            className="rounded-md border border-royal-border bg-royal-surface px-3 py-2 text-base font-semibold text-cream shadow-royal transition-colors hover:border-gold"
          >
            {theme === "dark" ? "☀" : "☾"}
          </button>
          <button
            type="button"
            onClick={() => setLanguage(language === "uk" ? "en" : "uk")}
            className="rounded-md border border-royal-border bg-royal-surface px-3 py-2 text-xs font-semibold text-cream shadow-royal transition-colors hover:border-gold"
          >
            {language === "uk" ? "EN" : "UK"}
          </button>
          {user ? (
            <Button asChild variant="royal" size="sm">
              <Link to="/dashboard">{t.nav.cabinet}</Link>
            </Button>
          ) : (
            <Button asChild variant="royalOutline" size="sm">
              <Link to="/login">{t.nav.login}</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  const { language } = useLanguage();
  return (
    <footer className="border-t border-royal-border px-5 py-12 text-center text-warm-muted md:px-10">
      <h2 className="text-2xl font-semibold tracking-[0.18em] text-gold">GROSS ACADEMY</h2>
      <p className="mt-3">{translations[language].footer}</p>
      <p className="mt-6 text-xs">
        © {new Date().getFullYear()} Gross Academy. {language === "en" ? "All rights reserved." : "Усі права захищені."}
      </p>
    </footer>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { language } = useLanguage();
  return (
    <main className="min-h-screen overflow-hidden bg-background text-foreground">
      <Header />
      {children}
      <Footer />
      <button
        type="button"
        onClick={() =>
          alert(
            language === "en"
              ? "AI assistant: Hi! How can I help with GROSS ACADEMY?"
              : "AI помічник: Привіт! Як я можу допомогти з GROSS ACADEMY?",
          )
        }
        aria-label="Open chat"
        className="fixed bottom-6 right-6 z-50 grid size-16 place-items-center rounded-full bg-[image:var(--gradient-gold)] text-2xl text-gold-foreground shadow-gold transition-transform hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        ♟
      </button>
    </main>
  );
}

export function SectionTitle({ kicker, title }: { kicker?: string; title: string }) {
  return (
    <div className="mb-14 text-center">
      {kicker && (
        <p className="text-sm font-semibold uppercase tracking-[0.32em] text-gold">{kicker}</p>
      )}
      <h1 className="mt-4 font-display text-4xl font-semibold leading-tight text-cream md:text-6xl">
        {title}
      </h1>
    </div>
  );
}

export function FormField({
  label,
  placeholder,
  type = "text",
  value,
  onChange,
}: {
  label: string;
  placeholder: string;
  type?: string;
  value?: string;
  onChange?: (value: string) => void;
}) {
  return (
    <label className="mt-5 block text-sm font-semibold text-gold">
      {label} *
      <input
        required
        type={type}
        value={value}
        onChange={onChange ? (event) => onChange(event.target.value) : undefined}
        placeholder={placeholder}
        className="mt-2 h-12 w-full rounded-md border border-royal-border bg-input px-4 text-cream placeholder:text-warm-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      />
    </label>
  );
}

export function ContactForm({ title, compact = false }: { title: string; compact?: boolean }) {
  const { language } = useLanguage();
  const t = translations[language];
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    alert(t.form.success);
    event.currentTarget.reset();
  }
  return (
    <form
      onSubmit={handleSubmit}
      className="mx-auto mt-12 max-w-2xl rounded-xl border border-royal-border bg-royal-surface-strong p-6 shadow-royal md:p-10"
    >
      <h2 className="mb-7 text-center text-3xl font-semibold text-gold">{title}</h2>
      {compact && (
        <label className="mb-5 block text-sm font-semibold text-gold">
          {t.form.program}
          <select
            required
            className="mt-2 h-12 w-full rounded-md border border-royal-border bg-input px-4 text-cream focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <option value="">{t.chooseProgram}</option>
            {programs.map((program) => (
              <option key={program.slug}>
                {localized(program.title, language)} — {localized(program.price, language)}
              </option>
            ))}
          </select>
        </label>
      )}
      <div className="grid gap-5 md:grid-cols-2">
        <FormField label={t.form.name} placeholder={t.form.name} />
        <FormField label={t.form.surname} placeholder={t.form.surname} />
      </div>
      <div className="mt-5 grid gap-5 md:grid-cols-2">
        <FormField label={t.form.email} type="email" placeholder="your@email.com" />
        <FormField label={t.form.phone} type="tel" placeholder="+38 (0XX) XXX-XX-XX" />
      </div>
      <Button type="submit" variant="royal" size="lg" className="mt-8 w-full uppercase tracking-[0.18em]">
        {t.form.submit}
      </Button>
    </form>
  );
}
